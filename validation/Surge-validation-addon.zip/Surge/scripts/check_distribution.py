"""Check product/validation boundaries without building or modifying the app."""

import argparse
import ast
import json
from pathlib import Path
import posixpath
import re
import subprocess

try:
    from .export_distribution import ROOT, prepare, stats, tree_hash
except ImportError:
    from export_distribution import ROOT, prepare, stats, tree_hash


def git_inventory(root, names, required=False):
    def git(*args):
        return subprocess.run(["git", "-C", str(root), *args], capture_output=True,
                              check=True, timeout=15)
    try:
        top = Path(git("rev-parse", "--show-toplevel").stdout.decode().strip()).resolve()
        if top != root:
            raise ValueError("Distribution check must use the active checkout root")
        raw = git("ls-files", "--cached", "--others", "--exclude-standard", "-z").stdout
    except (OSError, subprocess.SubprocessError, ValueError) as error:
        if required:
            raise ValueError("A Git checkout is required for the unclassified-file check") from error
        return "unavailable; exported-tree checks only"
    candidates = {item.decode("utf-8") for item in raw.split(b"\0") if item}
    unknown = sorted(candidates - names)
    if unknown:
        raise ValueError("Unclassified files: " + ", ".join(unknown) +
                         ". Classify source or explicitly ignore private/generated output.")
    return "passed"


def dependency_issues(master, product):
    issues = []
    def reject(source, candidates, required=False):
        # Resolve relative file names against the reviewed full source, never disk caches.
        for candidate in candidates:
            candidate = posixpath.normpath(candidate)
            if candidate in master:
                if candidate not in product:
                    issues.append(source + " depends on validation-only " + candidate)
                if source.endswith(".py"):
                    directory = posixpath.dirname(candidate)
                    while directory:
                        initializer = directory + "/__init__.py"
                        if initializer in master and initializer not in product:
                            issues.append(source + " depends on validation-only " + initializer)
                        directory = posixpath.dirname(directory)
                return
        if required:
            issues.append(source + " has missing local dependency " + candidates[0])
    def py_files(module):
        return [module + ".py", module + "/__init__.py"]
    for name, raw in product.items():
        parent = posixpath.dirname(name)
        if name.endswith(".py"):
            tree = ast.parse(raw.decode("utf-8-sig"), filename=name)
            for node in ast.walk(tree):
                modules = []
                if isinstance(node, ast.Import):
                    modules = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom):
                    prefix = (node.module or "").replace(".", "/")
                    if node.level:
                        base = parent
                        for _ in range(node.level - 1):
                            base = posixpath.dirname(base)
                        prefix = posixpath.join(base, prefix)
                        reject(name, py_files(prefix))
                        for alias in node.names:
                            reject(name, py_files(posixpath.join(prefix, alias.name)))
                        continue
                    modules = [node.module] if node.module else []
                    modules += [(node.module + "." if node.module else "") + alias.name
                                for alias in node.names if alias.name != "*"]
                for module in modules:
                    location = module.replace(".", "/")
                    reject(name, py_files(posixpath.join(parent, location)) + py_files(location))
        elif Path(name).suffix in {".js", ".cjs", ".mjs", ".jsx", ".css"}:
            pattern = r'''(?:from\s*|import\s*|require\(\s*|import\(\s*)["'](\.[^"']+)["']'''
            for match in re.finditer(pattern, raw.decode("utf-8-sig")):
                base = posixpath.normpath(posixpath.join(parent, match.group(1)))
                reject(name, [base] + [base + suffix for suffix in
                                      (".js", ".cjs", ".mjs", ".jsx", ".json", "/index.js", "/index.jsx")], required=True)
    return sorted(set(issues))


def lock_issues(product):
    """Read the fixed pnpm importer shape, not arbitrary YAML or dependency snapshots."""
    package = json.loads(product["desktop/package.json"])
    text = product["desktop/pnpm-lock.yaml"].decode().replace("\r\n", "\n")
    importer = re.search(r"(?ms)^importers:\n\n  \.:\n(.*?)(?=^[^ \n]|\Z)", text)
    if not importer:
        return ["Unsupported product lockfile importer; review its format"]
    found, section, name = {}, None, None
    for line in importer.group(1).splitlines():
        match = re.fullmatch(r"    (dependencies|devDependencies|optionalDependencies):", line)
        if match:
            section = match.group(1)
            found[section] = {}
            continue
        match = re.fullmatch(r"      (.+):", line)
        if match:
            name = match.group(1).strip("'\"")
            continue
        match = re.fullmatch(r"        specifier: (.+)", line)
        if match and section and name:
            found[section][name] = match.group(1).strip("'\"")
    expected = {section: package[section] for section in
                ("dependencies", "devDependencies", "optionalDependencies") if package.get(section)}
    return [] if found == expected else ["Product lockfile direct dependencies differ from package.json; regenerate and verify the frozen lockfile"]


def documentation_issues(product):
    issues = []
    for name, raw in product.items():
        if not name.endswith(".md"):
            continue
        for link in re.findall(r"\]\(([^)]+)\)", raw.decode("utf-8-sig")):
            target = link.split("#")[0]
            if not target or "://" in target or target.startswith("mailto:"):
                continue
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(name), target))
            if resolved not in product and not any(p.startswith(resolved.rstrip("/") + "/") for p in product):
                issues.append(name + " links to excluded/missing " + target)
    return issues


def check(root=ROOT, require_git=False):
    root = Path(root).resolve()
    master, product, validation, _ = prepare(root)
    git_status = git_inventory(root, set(master), require_git)
    issues = dependency_issues(master, product) + lock_issues(product) + documentation_issues(product)
    if issues:
        raise ValueError("Distribution check failed:\n- " + "\n- ".join(issues))
    return dict(passed=True, git_inventory=git_status, source_tree_sha256=tree_hash(master), product=stats(product),
                validation=stats(validation),
                scope="Classification, reviewed overrides, package metadata, literal imports and local links. Dynamic assets and consumer readiness require exported-tree build/smoke checks.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-git", action="store_true")
    args = parser.parse_args()
    print(json.dumps(check(require_git=args.require_git), indent=2))


if __name__ == "__main__":
    main()
