"""Require explicit package classification and reviewed product adaptations."""

import hashlib
import json

POLICY = "distribution/policy.json"
OVERRIDES = "distribution/product/"
SECTIONS = ("scripts", "dependencies", "devDependencies")


def normalized_hash(raw):
    """Ignore only checkout CRLF/LF differences, not substantive edits."""
    return hashlib.sha256(raw.replace(b"\r\n", b"\n")).hexdigest()


def prepare_package(master, product_names):
    """Validate immutable review bindings, then return product package metadata."""
    if POLICY not in master:
        raise ValueError("Missing reviewed distribution policy: " + POLICY)
    policy = json.loads(master[POLICY])
    if policy.get("schema") != "surge-distribution-policy-v1":
        raise ValueError("Unsupported distribution policy schema")
    overrides = {name[len(OVERRIDES):]: raw for name, raw in master.items()
                 if name.startswith(OVERRIDES)}
    for name in overrides:
        if name not in product_names:
            raise ValueError("Product override has no reviewed destination: " + name)
    bindings = policy.get("overrides")
    if not isinstance(bindings, dict) or bindings.keys() != overrides.keys():
        raise ValueError("Override review bindings must exactly cover product overrides")
    for name, raw in overrides.items():
        expected = {"source_sha256": normalized_hash(master[name]),
                    "override_sha256": normalized_hash(raw)}
        if bindings[name] != expected:
            raise ValueError("Product override review is stale: " + name
                             + "; review both files before updating policy hashes")

    package = json.loads(overrides.get("desktop/package.json", master["desktop/package.json"]))
    classifications = policy.get("package")
    if not isinstance(classifications, dict) or set(classifications) != set(SECTIONS):
        raise ValueError("Package policy must classify scripts, dependencies and devDependencies")
    for section in ("optionalDependencies", "peerDependencies", "bundledDependencies", "bundleDependencies"):
        if section in package:
            raise ValueError("Unsupported package dependency section requires policy review: " + section)
    for section in SECTIONS:
        entries = package.get(section, {})
        groups = classifications[section]
        if not isinstance(entries, dict) or not isinstance(groups, dict) or set(groups) != {"product", "validation"}:
            raise ValueError("Invalid package classification: " + section)
        names = []
        for group in ("product", "validation"):
            values = groups[group]
            if not isinstance(values, list) or any(not isinstance(name, str) for name in values):
                raise ValueError("Invalid package classification list: " + section)
            names.extend(values)
        if len(names) != len(set(names)) or set(names) != set(entries):
            raise ValueError("Package classification must cover every key exactly once: " + section)
        package[section] = {name: value for name, value in entries.items() if name in groups["product"]}
    return package
