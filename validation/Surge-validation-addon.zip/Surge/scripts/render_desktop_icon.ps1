# Render the authored silicon icon with Windows' vector drawing API.
# Small sizes simplify contacts and brighten the engraved S for recognition.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$assetPath = Join-Path (Split-Path $PSScriptRoot) 'desktop/assets'
# The contacts extend from 48 to 464. Keep a narrow clear edge at shell sizes.
$viewOrigin = 36
$viewSize = 512 - 2 * $viewOrigin
function Color([string]$value) { [System.Drawing.ColorTranslator]::FromHtml($value) }
function Points($values) { ,([System.Drawing.PointF[]]@($values | ForEach-Object { [System.Drawing.PointF]::new($_[0], $_[1]) })) }
$housing = @(@(104,72),@(408,72),@(440,104),@(440,408),@(408,440),@(104,440),@(72,408),@(72,104))
$inset = @(@(112,86),@(400,86),@(426,112),@(426,400),@(400,426),@(112,426),@(86,400),@(86,112))
$die = @(@(256,120),@(392,256),@(256,392),@(120,256))
$dieFace = @(@(256,137),@(375,256),@(256,375),@(137,256))
# The exact engraved S used by the landing processor, before its shared transform.
# M155 78H106L82 128H128L116 143H81L69 163H126L152 114H106L118 98H144Z
$stampSource = @(@(155,78),@(106,78),@(82,128),@(128,128),@(116,143),@(81,143),@(69,163),@(126,163),@(152,114),@(106,114),@(118,98),@(144,98))
$stampShear = [Math]::Tan(-10 * [Math]::PI / 180)
$stampDieScale = 272.0 / 156.0
function Stamp-Points($vertices, [double]$opticalScale = 1) {
    @($vertices | ForEach-Object {
        $stampX = $_[0] - 120
        $stampY = $_[1] - 120
        # translate(120 120) scale(.86) skewX(-10) translate(-120 -120),
        # then map the 240-unit processor die into this 512-unit icon.
        ,@((256 + ($stampX + $stampShear * $stampY) * .86 * $stampDieScale * $opticalScale),
           (256 + $stampY * .86 * $stampDieScale * $opticalScale))
    })
}
$stamp = Stamp-Points $stampSource
# Tiny frames enlarge the same silhouette rather than substituting a different S.
$stampSmall = Stamp-Points $stampSource 1.3
$processingHighlight = Stamp-Points @(@(130,88),@(140,88))
function Shape($vertices) {
    ($vertices | ForEach-Object {
        ($_[0].ToString('0.###', [Globalization.CultureInfo]::InvariantCulture)) + ',' +
        ($_[1].ToString('0.###', [Globalization.CultureInfo]::InvariantCulture))
    }) -join ' '
}
$pins = [System.Text.StringBuilder]::new()
foreach ($position in 128,160,192,224,256,288,320,352,384) {
    foreach ($box in @(@(($position-4),48,8,24),@(($position-4),440,8,24),@(48,($position-4),24,8),@(440,($position-4),24,8))) {
        [void]$pins.AppendLine("<rect x='$($box[0])' y='$($box[1])' width='$($box[2])' height='$($box[3])' fill='url(#copper)'/>")
    }
}
$svg = @"
<svg xmlns="http://www.w3.org/2000/svg" viewBox="$viewOrigin $viewOrigin $viewSize $viewSize">
  <defs>
    <linearGradient id="body" x2=".65" y2="1"><stop stop-color="#26323A"/><stop offset="1" stop-color="#0B1116"/></linearGradient>
    <linearGradient id="silicon" x2="1" y2="1"><stop stop-color="#3D4B53"/><stop offset=".55" stop-color="#202B32"/><stop offset="1" stop-color="#111A20"/></linearGradient>
    <linearGradient id="copper" x2="1" y2="1"><stop stop-color="#DFC495"/><stop offset=".48" stop-color="#A47F4D"/><stop offset="1" stop-color="#655337"/></linearGradient>
  </defs>
  $pins
  <polygon points="$(Shape $housing)" fill="url(#body)" stroke="#6E8089" stroke-width="3"/>
  <polygon points="$(Shape $inset)" fill="none" stroke="#47545C" stroke-width="2"/>
  <path d="M110 182V132H180 M402 330V380H332 M116 330V376H168 M396 182V136H346" fill="none" stroke="#3F5058" stroke-width="3"/>
  <polygon points="$(Shape $die)" fill="#142028" stroke="#677982" stroke-width="2"/>
  <polygon points="$(Shape $dieFace)" fill="url(#silicon)" stroke="#455A64" stroke-width="2"/>
  <polygon points="$(Shape $stamp)" transform="translate(0 3)" fill="#788D97"/>
  <polygon points="$(Shape $stamp)" fill="#091219" stroke="#536B77" stroke-width="2"/>
  <polyline points="$(Shape $processingHighlight)" fill="none" stroke="#79B6BC" stroke-width="2.2"/>
  <path d="M105 78H406L435 107 M126 256L256 126" fill="none" stroke="#A0AFB5" stroke-opacity=".5" stroke-width="2"/>
</svg>
"@
[System.IO.File]::WriteAllText((Join-Path $assetPath 'surge.svg'), $svg + "`n", [System.Text.UTF8Encoding]::new($false))
function Render([int]$size) {
    $bitmap = [System.Drawing.Bitmap]::new($size,$size)
    $canvas = [System.Drawing.Graphics]::FromImage($bitmap)
    $canvas.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $canvas.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $canvas.Clear([System.Drawing.Color]::Transparent)
    $scale = $size / $viewSize
    $offset = -$viewOrigin * $scale
    $transform = [System.Drawing.Drawing2D.Matrix]::new($scale,0,0,$scale,$offset,$offset)
    $canvas.Transform = $transform
    $transform.Dispose()
    function Face($values,$first,$last) {
        $brush = [System.Drawing.Drawing2D.LinearGradientBrush]::new([System.Drawing.Point]::new(72,72),[System.Drawing.Point]::new(440,440),(Color $first),(Color $last))
        $canvas.FillPolygon($brush,(Points $values)); $brush.Dispose()
    }
    function Outline($values,$hex,$width) {
        $pen = [System.Drawing.Pen]::new((Color $hex),$width)
        $canvas.DrawPolygon($pen,(Points $values)); $pen.Dispose()
    }
    function Line($values,$hex,$width) {
        $pen = [System.Drawing.Pen]::new((Color $hex),$width)
        $canvas.DrawLines($pen,(Points $values)); $pen.Dispose()
    }
    $positions = if ($size -le 24) { @(144,208,272,336) } else { @(128,160,192,224,256,288,320,352,384) }
    $contactWidth = if ($size -le 24) { 18 } else { 8 }
    $copper = [System.Drawing.Drawing2D.LinearGradientBrush]::new([System.Drawing.Point]::new(48,48),[System.Drawing.Point]::new(464,464),(Color '#DFC495'),(Color '#655337'))
    foreach ($position in $positions) {
        $canvas.FillRectangle($copper,($position-$contactWidth/2),48,$contactWidth,24)
        $canvas.FillRectangle($copper,($position-$contactWidth/2),440,$contactWidth,24)
        $canvas.FillRectangle($copper,48,($position-$contactWidth/2),24,$contactWidth)
        $canvas.FillRectangle($copper,440,($position-$contactWidth/2),24,$contactWidth)
    }
    $copper.Dispose()
    Face $housing '#26323A' '#0B1116'
    Outline $housing '#6E8089' $(if($size -le 32){8}else{3})
    if ($size -gt 32) {
        Outline $inset '#47545C' 2
        Line @(@(110,182),@(110,132),@(180,132)) '#3F5058' 3
        Line @(@(402,330),@(402,380),@(332,380)) '#3F5058' 3
        Line @(@(116,330),@(116,376),@(168,376)) '#3F5058' 3
        Line @(@(396,182),@(396,136),@(346,136)) '#3F5058' 3
    }
    Face $die '#32414A' '#142028'
    Outline $die '#677982' 2
    Face $dieFace '#3D4B53' '#111A20'
    if ($size -gt 32) {
        $shadow = $stamp | ForEach-Object { ,@($_[0],($_[1]+3)) }
        Face $shadow '#788D97' '#788D97'
        Face $stamp '#091219' '#091219'
        Outline $stamp '#536B77' 2
        Line $processingHighlight '#79B6BC' 2.2
    } else {
        # A light die stamp remains recognizable when subpixel bevels disappear.
        Face $stampSmall '#D3DCDD' '#9BAEB5'
    }
    $canvas.Dispose()
    return $bitmap
}
$bitmap = Render 512
$bitmap.Save((Join-Path $assetPath 'surge.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()
$sizes = @(16,20,24,32,40,48,64,128,256)
$payloads = @()
foreach ($size in $sizes) {
    $small = Render $size
    $stream = [System.IO.MemoryStream]::new()
    $small.Save($stream,[System.Drawing.Imaging.ImageFormat]::Png)
    $payloads += ,$stream.ToArray()
    $stream.Dispose(); $small.Dispose()
}
$output = [System.IO.File]::Create((Join-Path $assetPath 'surge.ico'))
$writer = [System.IO.BinaryWriter]::new($output)
$writer.Write([uint16]0); $writer.Write([uint16]1); $writer.Write([uint16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i=0; $i -lt $sizes.Count; $i++) {
    $dim = if ($sizes[$i] -eq 256) { 0 } else { $sizes[$i] }
    $writer.Write([byte]$dim); $writer.Write([byte]$dim); $writer.Write([byte]0); $writer.Write([byte]0)
    $writer.Write([uint16]1); $writer.Write([uint16]32)
    $writer.Write([uint32]$payloads[$i].Length); $writer.Write([uint32]$offset)
    $offset += $payloads[$i].Length
}
foreach ($bytes in $payloads) { $writer.Write([byte[]]$bytes) }
$writer.Dispose(); $output.Dispose()
Write-Output 'Wrote the SVG, PNG and multi-size ICO silicon S icon.'
