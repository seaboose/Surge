# Release checklist

Use one versioned release for each reviewed publication. Continue development in
small branches; leave the published assets unchanged until the next release.

1. Start from a reviewed snapshot of the full development checkout. Classify all
   file changes in `scripts/source-files.txt` and exactly one of the product or
   validation manifests. Synchronize product overrides and dependency lockfiles.
2. Review the diff and run `python scripts/check_distribution.py --require-git`. Exclude local
   paths, credentials, tool configuration, personal recordings, logs, drafts,
   backup archives and generated dependencies from both exports.
3. Run relevant tests and `scripts/check_release.py`; require applicable Windows
   CI to pass.
   Preserve failures privately and report any skipped or incomplete checks.
4. Generate a fresh product export and matching validation kit. Build and exercise
   the product tree with validation files absent. Build or explicitly identify
   reused runtime binaries. Verify required notices and record source, package,
   and per-file hashes. Never present repackaging as a rebuild.
5. Test the extracted gameplay-to-report flow and reopening. A new clean-machine
   claim requires a new guest test of that exact package.
6. Check the download, screenshot tour, code guide, and report links. Read the README
   as a first-time user; keep detailed procedures in `docs/`.
7. Publish only the software export to the public product repository. Do not push
   the full development checkout or its history. Publish the runnable application
   with today's actual date, checksums, and short notes after its release checks.
   Keep the matching validation kit private or publish it separately. Keep one
   current public release and preserve superseded artifacts in a verified private archive.

An export that excludes tests is not automatically consumer-ready. Incomplete
features stay on development branches; the current release remains available.
See [distribution rules](distribution.md) for file placement and exact restoration.

## Release note template

```text
Surge <version> — <YYYY-MM-DD>

Download the Windows ZIP, extract it, and open Surge.exe.

Changes: <brief behavior or packaging changes>.
Verified: <exact checks and source/package identifiers>.
Limits: <remaining gaps; distinguish host and clean-machine results>.
```

Use ordinary descriptive branch and commit names. Do not copy workstation details
or editing-session material into project documentation. Preserve required upstream
attribution for software actually distributed.
