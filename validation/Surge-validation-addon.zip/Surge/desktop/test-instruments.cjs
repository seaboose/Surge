// Follow the real navigation disclosure in integration tests.
async function revealInstrument(page, name) {
  const destinations = [
    "Data",
    "Results",
    "Compare",
    "Evaluate",
    "Case details",
    "Survive sessions",
    "Case library",
    "Back to Surge",
  ];
  if (
    destinations.includes(name) &&
    !(await page.getByRole("button", { name, exact: true }).count())
  )
    await page.getByRole("button", { name: "Tools", exact: true }).click();
}
module.exports = { revealInstrument };
