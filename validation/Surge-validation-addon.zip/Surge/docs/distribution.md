# Software and validation exports

Maintain one full development checkout. Make feature changes there and generate
fresh exports from reviewed snapshots; do not maintain a second hand-edited copy
of the product. The public software repository receives only the product export.
Never push the full development checkout or its history to that repository.

| Material | Destination |
| --- | --- |
| App/game code, required demos and assets, licenses, build support, product guides | `scripts/product-files.txt` |
| Tests, fixtures, benchmarks, qualification tools, development-only interfaces and reports | `scripts/validation-files.txt` |
| Personal recordings, credentials, local logs, installed dependencies, generated output and drafts | Ignored local storage; neither export |

The product and validation lists must be disjoint and together equal the reviewed
`scripts/source-files.txt` manifest. A filename containing "demo" or "fixture"
does not determine its destination: required in-app demonstrations and the native
baseline-approval build inputs remain product dependencies.

## Every feature change

1. Work on a focused `dev/<change>` branch in the full checkout. Keep the current
   published release intact while a feature is incomplete.
2. Classify every new, moved or removed file. Update the master list and exactly
   one distribution list; keep generated/private files ignored instead.
3. Keep product runtime and build code independent of validation-only files.
   Shared helpers needed by the product belong in the product list; tests may
   import them. Preserve required older adapters and demo assets.
4. Update matching files in `distribution/product/` when changing an overridden
   guide, setup behavior or dependency configuration. Regenerate the trimmed
   desktop lockfile when dependencies change, and verify it with a frozen install.
5. Run focused feature checks and the distribution check below. Before release,
   build and exercise the exported product tree with validation files absent.
   Record any skipped checks and unfinished work.

```powershell
python scripts/check_distribution.py --require-git
python scripts/check_release.py
```

These checks guard the file boundary; they do not establish feature completeness
or consumer readiness. Product classification means a file belongs to the
software, not that the current development branch is ready to publish.

The distribution check rejects unclassified Git files, literal product imports
of validation files, missing local product links, and mismatched direct lockfile
dependencies. `distribution/policy.json` explicitly classifies package commands
and dependencies. New entries require a decision before export. Its content
hashes bind each product override to its reviewed original and adapted file;
review both before updating a binding. Checks never refresh these hashes.

The development CI workflow runs this check and its focused regression tests.
For each new full development clone, enable the local public-push guard:

```powershell
git config --local core.hooksPath .githooks
```

The guard blocks direct pushes from this development tree to the public Surge
repository. Keep it enabled. Publish the product export through an isolated
staging checkout; preserve the existing public history unless a separate history
change has been explicitly approved. This local guard is not a server-side rule.

## Export a reviewed snapshot

Create a new pair of exports:

```powershell
python scripts/export_distribution.py --output-root <new-directory>
```

`Surge-software-source.zip` contains the application, owned demo/game source,
required assets, build support, licenses, and concise product documentation.
The exported package metadata omits Playwright, Prettier, and test commands.
Its lockfile is separately pinned in `distribution/product/desktop/pnpm-lock.yaml`.
It must match the exported `desktop/package.json` without the test dependencies.

`Surge-validation-addon.zip` contains tests, benchmarks, qualification tools,
historical evidence, and originals of files adapted for the product export.
Apply it only to a separate copy of its matching product export, using a short
local path to avoid Windows toolchain path limits. Its manifest
records the expected product fingerprint and the restored full-source fingerprint.
Overlaying the two archives restores the exact development snapshot, including
the original dependency lockfile and validation workflow. Run the source tests
from that restored tree; never overlay tests onto an installed application.

The exporter verifies the partitions, rejects linked/unsafe source paths, checks
every archive entry against its source bytes, and refuses to replace an existing
export directory. Its command-line entry point requires a Git checkout and runs
the distribution check before writing. The checked source fingerprint must match
the exported snapshot. It does not delete files from the development checkout or
modify a GitHub repository. A product source export is not an application binary
or a release qualification result. A consumer release is the separately built
Windows application package after its required checks have passed. Follow the
[release checklist](release-checklist.md) for publication.

Keep each product export, validation kit and receipt under the same version and
matching file fingerprints. Regenerate the pair after further source changes;
never attach an older test kit to a newer product export. Retain validation
privately until it is intentionally published as a separate artifact or project.

Tests already stay outside the installed application. Separating them reduces
source storage, not runtime allocations. Removing files from a new Git commit
does not erase previous public commits or reduce a full historical clone.
