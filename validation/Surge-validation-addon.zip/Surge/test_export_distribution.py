"""Small fixtures for product/validation separation and exact restoration."""

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from scripts import export_distribution as distribution
from scripts.distribution_policy import normalized_hash


class DistributionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="surge-distribution-")
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / "source"
        self.root.mkdir()
        self.product_names = {
            "README.md", "engine.py", "desktop/package.json",
            "scripts/product-files.txt", "scripts/source-files.txt",
        }
        self.validation_names = {
            "test_engine.py", "scripts/validation-files.txt",
            "distribution/product/README.md", "distribution/policy.json",
        }
        self.write("README.md", b"Development instructions\n")
        self.write("engine.py", b"def result():\n    return 42\n")
        self.write("test_engine.py", b"from engine import result\nassert result() == 42\n")
        self.write("distribution/product/README.md", b"Software instructions: caf\xc3\xa9\n")
        self.write("desktop/package.json", json.dumps({
            "name": "surge-desktop", "version": "1.2.3",
            "scripts": {"build": "node build.cjs", "start": "electron .",
                        "test": "node --test", "test:ui": "node ui.test.cjs",
                        "format": "prettier --write .", "format:check": "prettier --check ."},
            "dependencies": {"react": "1.2.3"},
            "devDependencies": {"electron": "1.2.3", "esbuild": "1.2.3",
                                "playwright": "1.2.3", "prettier": "1.2.3"},
        }).encode())
        self.review_policy()
        self.manifests()

    def review_policy(self):
        self.write("distribution/policy.json", json.dumps({
            "schema": "surge-distribution-policy-v1",
            "package": {
                "scripts": {"product": ["build", "start"],
                            "validation": ["test", "test:ui", "format", "format:check"]},
                "dependencies": {"product": ["react"], "validation": []},
                "devDependencies": {"product": ["electron", "esbuild"],
                                    "validation": ["playwright", "prettier"]},
            },
            "overrides": {"README.md": {
                "source_sha256": normalized_hash((self.root / "README.md").read_bytes()),
                "override_sha256": normalized_hash((self.root / "distribution/product/README.md").read_bytes()),
            }},
        }).encode())

    def write(self, name, raw):
        target = self.root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)

    def manifests(self):
        for name, names in (
            (distribution.PRODUCT, self.product_names),
            (distribution.VALIDATION, self.validation_names),
            ("scripts/source-files.txt", self.product_names | self.validation_names),
        ):
            self.write(name, ("\n".join(sorted(names)) + "\n").encode())

    def original_bytes(self):
        return {name: (self.root / name).read_bytes()
                for name in self.product_names | self.validation_names}

    def archive_bytes(self, path):
        with zipfile.ZipFile(path) as archive:
            self.assertIsNone(archive.testzip())
            self.assertEqual(len(archive.namelist()), len(set(archive.namelist())))
            self.assertTrue(all(name.startswith("Surge/") for name in archive.namelist()))
            return {name.removeprefix("Surge/"): archive.read(name)
                    for name in archive.namelist()}

    def test_separate_archives_restore_exact_development_source(self):
        original = self.original_bytes()
        output = self.base / "export"
        report = distribution.export(self.root, output,
                                     expected_source_hash=distribution.tree_hash(original))
        product = self.archive_bytes(output / "Surge-software-source.zip")
        validation = self.archive_bytes(output / "Surge-validation-addon.zip")
        self.assertEqual(set(product), self.product_names)
        self.assertNotIn("test_engine.py", product)
        self.assertIn("test_engine.py", validation)
        self.assertEqual(product["README.md"], b"Software instructions: caf\xc3\xa9\n")
        self.assertEqual({**product, **validation}, original)
        self.assertEqual(self.original_bytes(), original)
        package = json.loads(product["desktop/package.json"])
        self.assertEqual(package["scripts"], {"build": "node build.cjs", "start": "electron ."})
        self.assertEqual(package["devDependencies"], {"electron": "1.2.3", "esbuild": "1.2.3"})
        self.assertEqual(package["dependencies"], {"react": "1.2.3"})
        self.assertEqual(set(product["scripts/source-files.txt"].decode().splitlines()), set(product))
        for label, files in (("software-source", product), ("validation-addon", validation)):
            for name, raw in files.items():
                self.assertEqual((output / label / "Surge" / name).read_bytes(), raw)
            receipt = json.loads((output / (label + "-manifest.json")).read_text())
            self.assertEqual(set(receipt["files"]), set(files))
            self.assertEqual(receipt["product_tree_sha256"], report["product"]["tree_sha256"])
        self.assertEqual(report["restored_files"],
                         ["README.md", "desktop/package.json", "scripts/source-files.txt"])
        self.assertEqual(json.loads((output / "distribution.json").read_text()), report)
        # Uncompressed source size and compressed archive size are distinct fields.
        self.assertEqual(report["product"]["bytes"], sum(map(len, product.values())))
        self.assertEqual(report["product"]["archive"]["bytes"],
                         (output / "Surge-software-source.zip").stat().st_size)
        self.assertEqual(report["product"]["code_lines"], 2)
        self.assertEqual(report["validation"]["code_lines"], 2)
        self.assertEqual(report["reduction"]["bytes"],
                         sum(map(len, original.values())) - sum(map(len, product.values())))

    def test_manifests_must_be_complete_disjoint_partition(self):
        self.product_names.remove("engine.py")
        self.write(distribution.PRODUCT, ("\n".join(sorted(self.product_names)) + "\n").encode())
        with self.assertRaisesRegex(ValueError, "partition"):
            distribution.prepare(self.root)
        self.product_names.add("engine.py")
        self.validation_names.add("engine.py")
        self.manifests()
        with self.assertRaisesRegex(ValueError, "partition"):
            distribution.prepare(self.root)

    def test_product_rejects_obvious_tests_and_dependency_trees(self):
        for name in ("test_engine.py", "desktop/example.test.cjs",
                     "unreal/Game/telemetry/test_contract.py", "native/parser_tests.cpp",
                     "tests/fixture.json", "benchmarks/report.py",
                     "evidence/review.json", "node_modules/dependency/index.js",
                     "verification/result.json"):
            with self.subTest(name=name):
                self.write(name, b"Owned test fixture\n")
                self.validation_names.discard(name)
                self.product_names.add(name)
                self.manifests()
                with self.assertRaisesRegex(ValueError, "Validation/dependency"):
                    distribution.prepare(self.root)
                self.product_names.remove(name)
                self.validation_names.add(name)

    def test_rejects_missing_duplicate_and_unsafe_manifest_paths(self):
        manifest = self.root / distribution.PRODUCT
        original = manifest.read_bytes()
        for value, message in (("missing.py", "missing"),
                               ("README.md", "Duplicate"),
                               ("../outside.txt", "Invalid"),
                               ("folder\\escape.py", "Invalid"),
                               ("/absolute.txt", "Invalid")):
            with self.subTest(value=value):
                manifest.write_bytes(original + value.encode() + b"\n")
                with self.assertRaisesRegex(ValueError, message):
                    distribution.prepare(self.root)
        manifest.write_bytes(original)

    def test_rejects_linked_input(self):
        target = self.root / "README.md"
        target.unlink()
        outside = self.base / "outside.md"
        outside.write_text("Not source bytes\n")
        try:
            target.symlink_to(outside)
        except (OSError, NotImplementedError) as error:
            self.skipTest(f"Host does not permit symlink fixtures: {error}")
        with self.assertRaisesRegex(ValueError, "links"):
            distribution.prepare(self.root)

    def test_rejects_existing_output_and_source_ancestors(self):
        existing = self.base / "existing"
        existing.mkdir()
        marker = existing / "retain.txt"
        marker.write_bytes(b"Preserve prior output")
        with self.assertRaises(FileExistsError):
            distribution.export(self.root, existing)
        self.assertEqual(marker.read_bytes(), b"Preserve prior output")
        for destination in (self.root, self.base):
            with self.subTest(destination=destination):
                with self.assertRaisesRegex(ValueError, "ancestor"):
                    distribution.export(self.root, destination)

    def test_rejects_override_without_product_destination(self):
        name = "distribution/product/absent.md"
        self.write(name, b"Unexpected override\n")
        self.validation_names.add(name)
        self.manifests()
        with self.assertRaisesRegex(ValueError, "no reviewed destination"):
            distribution.prepare(self.root)

    def test_source_edit_after_preflight_rejects_before_writing(self):
        reviewed_hash = distribution.tree_hash(self.original_bytes())
        self.write("engine.py", b"def result():\n    return 43\n")
        output = self.base / "changed-after-check"
        with self.assertRaisesRegex(ValueError, "Source changed after distribution checks"):
            distribution.export(self.root, output, expected_source_hash=reviewed_hash)
        self.assertFalse(output.exists())

    def test_source_edit_during_export_cannot_receive_success_receipt(self):
        write_archive = distribution.write_archive
        output = self.base / "changed-export"

        def write_and_edit(destination, label, files):
            result = write_archive(destination, label, files)
            if label == "software-source":
                self.write("engine.py", b"def result():\n    return 43\n")
            return result

        with patch.object(distribution, "write_archive", side_effect=write_and_edit):
            with self.assertRaisesRegex(ValueError, "Source changed during export"):
                distribution.export(self.root, output)
        self.assertFalse((output / "distribution.json").exists())
        self.assertTrue((output / "Surge-software-source.zip").exists())


if __name__ == "__main__":
    unittest.main()
