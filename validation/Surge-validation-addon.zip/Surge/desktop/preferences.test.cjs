const test = require("node:test");
const assert = require("node:assert/strict");
const preferences = import("./src/case-workspace/preferences.mjs");

test("missing preferences follow the system without opting into startup opening", async () => {
  const { parsePreferences } = await preferences;
  assert.deepEqual(parsePreferences(null), {
    version: 1,
    reduceMotion: null,
    openLatestCase: false,
  });
});

test("malformed or unsupported stored values cannot opt into opening a case", async () => {
  const { parsePreferences } = await preferences;
  for (const text of [
    "broken",
    "null",
    "{}",
    JSON.stringify({ version: 2, reduceMotion: true, openLatestCase: true }),
    JSON.stringify({ version: 1, reduceMotion: "true", openLatestCase: true }),
    JSON.stringify({ version: 1, reduceMotion: null, openLatestCase: "yes" }),
  ]) {
    assert.throws(() => parsePreferences(text));
  }
});

test("saved motion overrides and startup choice survive serialization", async () => {
  const { parsePreferences } = await preferences;
  for (const reduceMotion of [null, false, true]) {
    const value = { version: 1, reduceMotion, openLatestCase: true };
    assert.deepEqual(
      parsePreferences(JSON.stringify({ ...value, unrelated: "ignored" })),
      value,
    );
  }
});

test("startup selects newest saved case deterministically and tolerates empty entries", async () => {
  const { newestCase } = await preferences;
  const entries = [
    { id: "older", created: "2026-10-31T18:00:00Z" },
    { id: "z", created: "2026-11-06T12:00:00Z" },
    { id: "a", created: "2026-11-06T12:00:00Z" },
    null,
    { id: "broken", created: "not a date" },
  ];
  assert.equal(newestCase(entries).id, "a");
  assert.equal(entries[0].id, "older");
  assert.equal(newestCase([]), undefined);
  assert.equal(newestCase(null), undefined);
});
