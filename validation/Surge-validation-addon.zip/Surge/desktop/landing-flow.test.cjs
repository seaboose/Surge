// A focused real desktop journey. Only native file/confirmation dialogs are
// supplied by the test driver; every workspace mutation uses a visible control.
const { _electron: electron } = require("playwright");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const outputRoot = path.resolve(
  process.env.SURGE_UI_TEST_OUTPUT || path.join(__dirname, "../verification"),
);
fs.mkdirSync(outputRoot, { recursive: true });
const out = fs.mkdtempSync(path.join(outputRoot, "landing-flow-"));
const packagedExecutable = process.env.SURGE_TEST_EXECUTABLE
  ? path.resolve(process.env.SURGE_TEST_EXECUTABLE)
  : null;
const profile = path.join(out, "profile");
const entry = path.join(out, "entry.cjs");
fs.writeFileSync(
  entry,
  `const {app}=require('electron');app.setPath('userData',${JSON.stringify(profile)});require(${JSON.stringify(path.join(__dirname, "main.cjs"))});`,
);
const recorded = JSON.parse(
  fs.readFileSync(
    path.join(__dirname, "../demos/native/approved-update.case.json"),
    "utf8",
  ),
);
const evidence = path.join(out, "baseline-observations.jsonl");
fs.writeFileSync(evidence, recorded.payload.current.text);
let app, page;
const checks = [],
  errors = [],
  measurements = [];
const button = (name, scope = page) =>
  scope.getByRole("button", { name, exact: true });
const ready = () =>
  page.waitForFunction(
    () => document.querySelector(".app")?.dataset.working === "false",
  );
const rpc = (method) =>
  page.evaluate(async (method) => {
    const reply = await window.surge.request(method, {});
    if (!reply.ok) throw Error(reply.error);
    return reply.value;
  }, method);
async function click(name, scope = page) {
  await button(name, scope).click();
  await ready();
}
async function home() {
  await button("Home").click();
  await button("Open evidence").waitFor();
  await ready();
}
async function check(name, action) {
  await action();
  checks.push(name);
  console.log("PASS", name);
}
async function audit(name) {
  await page.evaluate(() => document.fonts.ready);
  if (await page.locator(".packet-scene").count()) {
    await page.waitForFunction(() => {
      const canvas = document.querySelector(".canopy-canvas");
      const app = document.querySelector(".app").getBoundingClientRect();
      return (
        canvas.width ===
        Math.round(app.width * Math.min(devicePixelRatio || 1, 2))
      );
    });
  }
  const issues = await page.evaluate(() => {
    const found = [];
    if (document.documentElement.scrollWidth > innerWidth + 2)
      found.push("page overflow");
    const title = [...document.querySelectorAll("h1")].find((e) =>
      e.checkVisibility(),
    );
    const titleSize = title && parseFloat(getComputedStyle(title).fontSize);
    for (const el of document.querySelectorAll(
      "h1,h2,h3,button,small,p,span",
    )) {
      if (!el.checkVisibility()) continue;
      const style = getComputedStyle(el);
      if (!style.fontFamily.includes("Inter"))
        found.push("font: " + el.textContent.slice(0, 35));
      if (el.matches("h2,h3") && parseFloat(style.fontSize) >= titleSize)
        found.push("hierarchy: " + el.textContent);
      if (el.matches("button") && el.scrollWidth > el.clientWidth + 3)
        found.push("button text overflow: " + el.textContent);
    }
    return found;
  });
  assert.deepEqual(issues, [], name);
  await page.screenshot({ path: path.join(out, name + ".png") });
}
async function launch() {
  const env = {
    ...process.env,
    SURGE_PRESENTATION: '{"point":{"x":-540,"y":936},"hidden":true}',
  };
  delete env.ELECTRON_RUN_AS_NODE;
  app = await electron.launch({
    executablePath: packagedExecutable || require("electron"),
    args: packagedExecutable ? [`--user-data-dir=${profile}`] : [entry],
    cwd: packagedExecutable ? path.dirname(packagedExecutable) : __dirname,
    chromiumSandbox: true,
    env,
  });
  page = await app.firstWindow();
  page.setDefaultTimeout(15000);
  page.on("pageerror", (error) => errors.push(error.message));
}
(async () => {
  await launch();
  await button("Open evidence").waitFor();
  const identity = await app.evaluate(({ app, BrowserWindow }) => ({
    packaged: app.isPackaged,
    executable: process.execPath,
    profile: app.getPath("userData"),
    visible: BrowserWindow.getAllWindows()[0].isVisible(),
    preferences:
      BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences(),
  }));
  assert.equal(identity.packaged, !!packagedExecutable);
  assert.equal(
    path.resolve(identity.profile).toLowerCase(),
    profile.toLowerCase(),
  );
  assert.equal(identity.visible, false);
  assert.equal(identity.preferences.sandbox, true);
  assert.equal(identity.preferences.contextIsolation, true);
  assert.equal(identity.preferences.nodeIntegration, false);
  if (packagedExecutable)
    assert.equal(
      path.resolve(identity.executable).toLowerCase(),
      packagedExecutable.toLowerCase(),
    );
  await check(
    "direct landing actions, optical identity, and empty recents",
    async () => {
      await button("Start capture").waitFor();
      await button("Try Demo").waitFor();
      assert.equal(
        await page.locator(".packet-scene").getAttribute("data-route-count"),
        "32",
      );
      assert.equal(await button("Survive sessions").isVisible(), false);
      assert.equal(await page.locator(".optical-aperture").count(), 0);
      await page
        .getByRole("region", { name: "Recent cases", exact: true })
        .getByText("No saved cases yet.", { exact: true })
        .waitFor();
      const open = await button("Open evidence").boundingBox();
      const capture = await button("Start capture").boundingBox();
      const demo = await button("Try Demo").boundingBox();
      assert.ok(demo.y < Math.min(open.y, capture.y));
      assert.ok(demo.height < open.height);
    },
  );
  await check(
    "canceling Open evidence keeps Home and the empty workspace",
    async () => {
      await app.evaluate(({ dialog }) => {
        dialog.showOpenDialog = async () => ({ canceled: true, filePaths: [] });
      });
      await click("Open evidence");
      assert.equal((await rpc("state")).current, null);
      await button("Open evidence").waitFor();
    },
  );
  await check(
    "Open evidence imports actual records for analysis and saving",
    async () => {
      await app.evaluate(({ dialog }, file) => {
        dialog.showOpenDialog = async () => ({
          canceled: false,
          filePaths: [file],
        });
      }, evidence);
      await click("Open evidence");
      await page.getByRole("table", { name: "Preview", exact: true }).waitFor();
      await click("Analyze");
      await page.getByRole("table", { name: "Results", exact: true }).waitFor();
      const state = await rpc("state");
      assert.equal(state.current.sha256, recorded.payload.current.sha256);
      assert.equal(state.summary.total, recorded.payload.current.records);
      await click("Save case");
      await page
        .getByLabel("Case name", { exact: true })
        .fill("Baseline capture");
      await click("Save to library");
      await page
        .getByRole("region", { name: "Case saved", exact: true })
        .waitFor();
      await home();
      const recent = page.getByRole("region", {
        name: "Recent cases",
        exact: true,
      });
      await button("Baseline capture", recent).waitFor();
      await audit("home");
      await click("Baseline capture", recent);
      await page.getByRole("table", { name: "Results", exact: true }).waitFor();
      assert.equal((await rpc("state")).current.sha256, state.current.sha256);
      await home();
    },
  );
  await check(
    "settings persist and startup opens the latest real case once",
    async () => {
      await button("Settings").click();
      await page
        .getByRole("switch", { name: "Reduce motion", exact: true })
        .click();
      await page
        .getByRole("switch", {
          name: "Open latest case on startup",
          exact: true,
        })
        .click();
      await page.waitForFunction(
        () => document.documentElement.dataset.reducedMotion === "true",
      );
      await audit("settings");
      await page.keyboard.press("Escape");
      assert.equal(
        await button("Settings").evaluate(
          (el) => el === document.activeElement,
        ),
        true,
      );
      await app.close();
      app = null;
      await launch();
      await page.getByRole("table", { name: "Results", exact: true }).waitFor();
      assert.equal(
        (await rpc("state")).current.sha256,
        recorded.payload.current.sha256,
      );
      assert.equal(
        await page.evaluate(
          () => document.documentElement.dataset.reducedMotion,
        ),
        "true",
      );
      await home();
      await button("Settings").click();
      assert.equal(
        await page
          .getByRole("switch", {
            name: "Open latest case on startup",
            exact: true,
          })
          .getAttribute("aria-checked"),
        "true",
      );
      await page.keyboard.press("Escape");
      await button("Open evidence").waitFor();
    },
  );
  await check(
    "Try Demo contains Survive and Code integrity with direct Home",
    async () => {
      await click("Try Demo");
      await button("Survive").waitFor();
      await button("Code integrity").waitFor();
      await audit("demo-chooser");
      await button("Survive").click();
      await page
        .getByRole("heading", { name: "Survive sessions", exact: true })
        .waitFor();
      await button("Play and record trial").waitFor();
      await home();
      await click("Try Demo");
      await click("Code integrity");
      await button("Start collection").waitFor();
      await home();
    },
  );
  await check(
    "Start capture exposes supported sources and the game recorder",
    async () => {
      await click("Start capture");
      await button("Owned process").waitFor();
      await button("Survive telemetry").waitFor();
      await audit("capture-chooser");
      await button("Survive telemetry").click();
      await page
        .getByRole("heading", { name: "Survive sessions", exact: true })
        .waitFor();
      await home();
    },
  );
  await check(
    "Home preserves live capture and its reachable Stop control",
    async () => {
      await click("Start capture");
      await click("Owned process");
      await click("Start collection");
      let running;
      const deadline = Date.now() + 15000;
      do {
        running = (await rpc("native_status")).capture;
        assert.notEqual(running?.state, "failed", running?.error);
        if (running?.samples > 0 && running.session_id) break;
        await new Promise((resolve) => setTimeout(resolve, 100));
      } while (Date.now() < deadline);
      assert.ok(
        running?.samples > 0 && running.session_id,
        "identified live samples",
      );
      await home();
      await page
        .getByText("Live capture is running", { exact: true })
        .waitFor();
      await button("Stop collection").waitFor();
      const current = (await rpc("native_status")).capture;
      assert.equal(current.state, "running");
      assert.equal(current.session_id, running.session_id);
      await click("Return to capture");
      await click("Stop collection");
      await page.getByRole("table", { name: "Results", exact: true }).waitFor();
      const inspected = await rpc("state");
      assert.ok(inspected.summary.total > 0);
      await page
        .getByLabel("Search records", { exact: true })
        .fill("LabCodeProbe");
      await home();
      await click("Return to evidence");
      assert.equal(
        await page.getByLabel("Search records", { exact: true }).inputValue(),
        "LabCodeProbe",
      );
      assert.equal(
        (await rpc("state")).current.sha256,
        inspected.current.sha256,
      );
      await home();
    },
  );
  await check(
    "recent cases refresh after library rename and deletion",
    async () => {
      await click("All cases");
      const library = page.getByRole("dialog", {
        name: "Case library",
        exact: true,
      });
      const oldRow = library
        .locator(".case-list li")
        .filter({ hasText: "Baseline capture" });
      await click("Rename", oldRow);
      await oldRow
        .getByLabel("New case name", { exact: true })
        .fill("Baseline review");
      await click("Save name", oldRow);
      await library.getByText("Baseline review", { exact: true }).waitFor();
      await click("Close", library);
      const recent = page.getByRole("region", {
        name: "Recent cases",
        exact: true,
      });
      await button("Baseline review", recent).waitFor();
      assert.equal(await button("Baseline capture", recent).count(), 0);
      await click("All cases");
      await app.evaluate(({ dialog }) => {
        dialog.showMessageBox = async () => ({ response: 1 });
      });
      await click(
        "Delete case",
        library.locator(".case-list li").filter({ hasText: "Baseline review" }),
      );
      await click("Close", library);
      await recent.getByText("No saved cases yet.", { exact: true }).waitFor();
      assert.equal((await rpc("library_list")).entries.length, 0);
      assert.ok(
        (await rpc("state")).current,
        "deletion retains current evidence",
      );
    },
  );
  await check(
    "narrow layout retains actions, text hierarchy, and keyboard focus",
    async () => {
      await app.evaluate(({ BrowserWindow }) =>
        BrowserWindow.getAllWindows()[0].setContentSize(760, 880),
      );
      await page.waitForFunction(() => innerWidth === 760);
      const viewport = await page.evaluate(() => ({
        name: "narrow viewport",
        width: innerWidth,
        height: innerHeight,
      }));
      measurements.push(viewport);
      assert.equal(viewport.width, 760, "actual CSS viewport is 760px wide");
      await audit("home-narrow");
      assert.equal(
        await page.getByLabel("Search records", { exact: true }).isVisible(),
        false,
        "retained evidence controls stay hidden on Home",
      );
      await button("Open evidence").focus();
      await page.keyboard.press("Tab");
      assert.equal(
        await button("Start capture").evaluate(
          (el) => el === document.activeElement,
        ),
        true,
      );
      await page.keyboard.press("Tab");
      assert.equal(
        await button("All cases").evaluate(
          (el) => el === document.activeElement,
        ),
        true,
      );
      assert.deepEqual(errors, []);
    },
  );
  await check("reduced motion leaves the optical routes static", async () => {
    await page.emulateMedia({ reducedMotion: "reduce" });
    assert.equal(await page.locator(".processor-packet").count(), 3);
    assert.equal(await page.locator(".canopy-canvas").count(), 2);
    const motion = await page.evaluate(() => ({
      name: "reduced motion",
      preference: matchMedia("(prefers-reduced-motion: reduce)").matches,
      elements: [...document.querySelectorAll(".processor-packet")].map(
        (element) => {
          const style = getComputedStyle(element);
          return {
            animation: style.animationName,
            transition: style.transitionDuration,
          };
        },
      ),
    }));
    assert.equal(motion.preference, true);
    for (const element of motion.elements) {
      assert.equal(element.animation, "none");
      assert.ok(
        element.transition
          .split(",")
          .every((duration) => parseFloat(duration) === 0),
      );
    }
    measurements.push(motion);
    assert.equal(
      await page.locator(".packet-scene").getAttribute("data-route-count"),
      "32",
    );
    await button("Open evidence").waitFor();
    await button("Start capture").waitFor();
    await button("Try Demo").waitFor();
  });
  await check("startup with an empty library returns to Home", async () => {
    await app.close();
    app = null;
    await launch();
    await button("Open evidence").waitFor();
    await page.getByText("No saved cases yet.", { exact: true }).waitFor();
    assert.equal((await rpc("state")).current, null);
    await button("Settings").click();
    assert.equal(
      await page
        .getByRole("switch", {
          name: "Open latest case on startup",
          exact: true,
        })
        .getAttribute("aria-checked"),
      "true",
    );
    await page.keyboard.press("Escape");
    await audit("home-empty");
  });
  const result = {
    passed: true,
    checks,
    identity,
    measurements,
    evidence: out,
  };
  fs.writeFileSync(
    path.join(out, "result.json"),
    JSON.stringify(result, null, 2),
  );
  console.log(JSON.stringify(result));
})()
  .catch(async (error) => {
    console.error(error);
    process.exitCode = 1;
    if (page)
      await page
        .screenshot({ path: path.join(out, "failure.png") })
        .catch(() => {});
  })
  .finally(async () => {
    if (app) await app.close();
  });
