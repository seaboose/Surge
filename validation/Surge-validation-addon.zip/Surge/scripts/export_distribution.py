"""Export software source and a matching, separately restorable validation kit."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

try:
    from .distribution_policy import prepare_package
    from .release_files import ROOT, reviewed_file, source_files
except ImportError:
    from distribution_policy import prepare_package
    from release_files import ROOT, reviewed_file, source_files

PRODUCT = "scripts/product-files.txt"
VALIDATION = "scripts/validation-files.txt"
CODE_SUFFIXES = {".py", ".cjs", ".mjs", ".js", ".jsx", ".css", ".html", ".ps1", ".cmd",
                 ".cpp", ".h", ".hpp", ".c", ".cs", ".asm", ".def"}
FORBIDDEN = re.compile(r"((^|/)test[_-]|\.test\.[cm]?js$|_tests\.(cpp|py)$|AutomationTests\.cpp$|(^|/)(tests|benchmarks|evidence|node_modules|verification)/)")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_manifest(root, relative):
    path = reviewed_file(root, relative)
    names = [line.strip() for line in path.read_text(encoding="utf-8").splitlines()
             if line.strip() and not line.lstrip().startswith("#")]
    if len(names) != len({name.casefold() for name in names}):
        raise ValueError("Duplicate distribution path")
    for name in names:
        reviewed_file(root, name)
    return set(names)


def stats(files):
    code = {name: raw for name, raw in files.items()
            if Path(name).suffix.lower() in CODE_SUFFIXES or Path(name).name == "CMakeLists.txt"}
    return dict(files=len(files), bytes=sum(map(len, files.values())), code_files=len(code),
                code_lines=sum(len(raw.decode("utf-8-sig").splitlines()) for raw in code.values()))


def inventory(files):
    return {name: dict(bytes=len(raw), sha256=digest(raw)) for name, raw in sorted(files.items())}


def tree_hash(files):
    return digest(json.dumps(inventory(files), sort_keys=True, separators=(",", ":")).encode())


def prepare(root):
    root = Path(root).resolve()
    master = {path.relative_to(root).as_posix(): path.read_bytes() for path in source_files(root)}
    product_names = read_manifest(root, PRODUCT)
    validation_names = read_manifest(root, VALIDATION)
    if product_names & validation_names or product_names | validation_names != master.keys():
        raise ValueError("Product and validation manifests must partition the reviewed source")
    if PRODUCT not in product_names or "scripts/source-files.txt" not in product_names:
        raise ValueError("Product source manifests are required")
    forbidden = sorted(name for name in product_names if FORBIDDEN.search(name))
    if forbidden:
        raise ValueError("Validation/dependency files in product: " + ", ".join(forbidden))
    package = prepare_package(master, product_names)
    product = {name: master[name] for name in product_names}
    override_root = "distribution/product/"
    for source, raw in master.items():
        if source.startswith(override_root):
            destination = source[len(override_root):]
            if destination not in product:
                raise ValueError("Product override has no reviewed destination: " + destination)
            product[destination] = raw
    product["desktop/package.json"] = (json.dumps(package, indent=2) + "\n").encode()
    product["scripts/source-files.txt"] = ("\n".join(sorted(product_names)) + "\n").encode()
    changed = sorted(name for name, raw in product.items() if raw != master[name])
    validation = {name: master[name] for name in validation_names | set(changed)}
    restored = {**product, **validation}
    if restored != master:
        raise ValueError("Validation overlay does not restore the exact development source")
    return master, product, validation, changed


def write_archive(destination, label, files):
    tree = destination / label / "Surge"
    tree.mkdir(parents=True, exist_ok=False)
    archive_path = destination / ("Surge-" + label + ".zip")
    with zipfile.ZipFile(archive_path, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(files.items()):
            target = tree / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            archive.writestr("Surge/" + name, raw)
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(files):
            raise ValueError("Distribution archive verification failed")
        for name, raw in files.items():
            if archive.read("Surge/" + name) != raw or (tree / name).read_bytes() != raw:
                raise ValueError("Distribution bytes differ: " + name)
    return dict(archive=dict(name=archive_path.name, bytes=archive_path.stat().st_size,
                             sha256=digest(archive_path.read_bytes())),
                **stats(files), tree_sha256=tree_hash(files))


def export(root, destination, expected_source_hash=None):
    root = Path(root).resolve()
    destination = Path(destination).resolve()
    if destination == root or destination in root.parents:
        raise ValueError("Output must not replace the source tree or an ancestor")
    master, product, validation, changed = prepare(root)
    if expected_source_hash is not None and tree_hash(master) != expected_source_hash:
        raise ValueError("Source changed after distribution checks; run checks and export again")
    # A new directory prevents replacement of an earlier export or its receipts.
    destination.mkdir(parents=True, exist_ok=False)
    report = dict(schema="surge-distribution-v1", version=json.loads(product["desktop/package.json"])["version"],
                  developer_source=stats(master), source_tree_sha256=tree_hash(master),
                  product=write_archive(destination, "software-source", product),
                  validation=write_archive(destination, "validation-addon", validation),
                  restored_files=changed, restoration="Exact full-source bytes after applying the matching validation overlay",
                  runtime_ram_savings="Not measured; excluding unused source/tests does not reduce runtime allocations")
    report["reduction"] = {key: report["developer_source"][key] - report["product"][key]
                           for key in ("files", "bytes", "code_files", "code_lines")}
    for label, files in (("software-source", product), ("validation-addon", validation)):
        data = dict(schema="surge-distribution-files-v1", files=inventory(files),
                    product_tree_sha256=tree_hash(product), source_tree_sha256=tree_hash(master))
        (destination / (label + "-manifest.json")).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    # Re-read all source bytes after export: a concurrent edit invalidates this attempt.
    current = {path.relative_to(root).as_posix(): path.read_bytes() for path in source_files(root)}
    if current != master:
        raise ValueError("Source changed during export; preserve this attempt and use a new output directory")
    (destination / "distribution.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True, help="New output directory")
    args = parser.parse_args()
    try:
        from .check_distribution import check
    except ImportError:
        from check_distribution import check
    preflight = check(require_git=True)
    report = export(ROOT, args.output_root, expected_source_hash=preflight["source_tree_sha256"])
    print(json.dumps({key: report[key] for key in ("version", "developer_source", "product", "validation", "reduction")}, indent=2))


if __name__ == "__main__":
    main()
