"""Regressions for future feature classification and product dependency drift."""

import json
from pathlib import Path
import subprocess
import tempfile
import unittest

from scripts.check_distribution import (dependency_issues, documentation_issues,
                                        git_inventory, lock_issues)


class BoundaryChecks(unittest.TestCase):
    def test_new_unclassified_file_fails_until_classified_or_ignored(self):
        with tempfile.TemporaryDirectory(prefix="surge-boundary-") as folder:
            root = Path(folder).resolve()
            subprocess.run(["git", "init", "--quiet", str(root)], check=True, capture_output=True)
            (root / "engine.py").write_text("value = 1\n")
            (root / "new_feature.py").write_text("value = 2\n")
            with self.assertRaisesRegex(ValueError, "Unclassified files: new_feature.py"):
                git_inventory(root, {"engine.py"}, required=True)
            self.assertEqual(git_inventory(root, {"engine.py", "new_feature.py"}, True), "passed")
            (root / ".gitignore").write_text("new_feature.py\n")
            self.assertEqual(git_inventory(root, {"engine.py", ".gitignore"}, True), "passed")

    def test_product_imports_cannot_reach_validation_files(self):
        master = {"engine.py": b"import test_helpers\n", "test_helpers.py": b"value=1\n",
                  "scripts/build.py": b"from . import test_tools\n", "scripts/test_tools.py": b"",
                  "desktop/src/App.jsx": b'import "../helper.cjs";\n', "desktop/helper.cjs": b""}
        product = {name: master[name] for name in ("engine.py", "scripts/build.py", "desktop/src/App.jsx")}
        issues = dependency_issues(master, product)
        self.assertEqual(len(issues), 3)
        self.assertTrue(all("validation-only" in issue for issue in issues))
        self.assertEqual(dependency_issues(master, master), [])

    def test_missing_relative_renderer_import_is_reported(self):
        product = {"desktop/src/App.jsx": b'import "./Missing.jsx";\n'}
        self.assertIn("missing local dependency", dependency_issues(product, product)[0])

    def test_python_imports_include_parent_package_initializers(self):
        for source, statement in (
                ("app.py", b"import namespace.package.feature\n"),
                ("app.py", b"from namespace.package import feature\n"),
                ("namespace/package/app.py", b"from . import feature\n"),
                ("namespace/package/app.py", b"from ..package.feature import value\n")):
            with self.subTest(statement=statement):
                master = {source: statement, "namespace/package/feature.py": b"value = 1\n",
                          "namespace/__init__.py": b"", "namespace/package/__init__.py": b""}
                product = {name: raw for name, raw in master.items() if not name.endswith("__init__.py")}
                self.assertEqual(dependency_issues(master, product), [
                    source + " depends on validation-only namespace/__init__.py",
                    source + " depends on validation-only namespace/package/__init__.py"])
                self.assertEqual(dependency_issues(master, master), [])
                del master["namespace/__init__.py"]  # Namespace packages need no fabricated initializer.
                self.assertEqual(dependency_issues(master, product), [
                    source + " depends on validation-only namespace/package/__init__.py"])

    def test_product_lockfile_tracks_direct_dependency_versions(self):
        product = {"desktop/package.json": json.dumps({"dependencies": {"react": "1.2.3"}}).encode(),
                   "desktop/pnpm-lock.yaml": b"importers:\n\n  .:\n    dependencies:\n      react:\n        specifier: 1.2.3\n        version: 1.2.3\n\npackages:\n"}
        self.assertEqual(lock_issues(product), [])
        product["desktop/pnpm-lock.yaml"] = product["desktop/pnpm-lock.yaml"].replace(b"\n", b"\r\n")
        self.assertEqual(lock_issues(product), [])
        product["desktop/package.json"] = b'{"dependencies":{"react":"2.0.0"}}'
        self.assertIn("direct dependencies differ", lock_issues(product)[0])

    def test_product_documentation_cannot_link_to_excluded_test_guides(self):
        product = {"README.md": b"[guide](docs/tests.md) [external](https://example.com/) [anchor](#local)"}
        self.assertEqual(documentation_issues(product), ["README.md links to excluded/missing docs/tests.md"])
        product["docs/tests.md"] = b"Guide"
        self.assertEqual(documentation_issues(product), [])


if __name__ == "__main__":
    unittest.main()
