"""Regression checks for unreviewed package entries and stale adaptations."""

import copy
import json
import unittest

from scripts.distribution_policy import POLICY, normalized_hash, prepare_package


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.package = {"scripts": {"start": "electron .", "check": "node check.cjs"},
                        "dependencies": {"react": "1"},
                        "devDependencies": {"electron": "1", "test-runner": "1"}}
        self.master = {"README.md": b"Full source\n",
                       "distribution/product/README.md": b"Software only\n"}
        self.policy = {
            "schema": "surge-distribution-policy-v1",
            "package": {
                "scripts": {"product": ["start"], "validation": ["check"]},
                "dependencies": {"product": ["react"], "validation": []},
                "devDependencies": {"product": ["electron"], "validation": ["test-runner"]},
            },
            "overrides": {"README.md": {
                "source_sha256": normalized_hash(self.master["README.md"]),
                "override_sha256": normalized_hash(self.master["distribution/product/README.md"]),
            }},
        }

    def prepare(self):
        self.master[POLICY] = json.dumps(self.policy).encode()
        self.master["desktop/package.json"] = json.dumps(self.package).encode()
        return prepare_package(self.master, {"README.md", "desktop/package.json"})

    def test_explicit_classification_preserves_product_values(self):
        self.assertEqual(self.prepare(), {"scripts": {"start": "electron ."},
                                         "dependencies": {"react": "1"},
                                         "devDependencies": {"electron": "1"}})

    def test_new_scripts_and_dependencies_require_classification(self):
        for section in self.package:
            with self.subTest(section=section):
                self.package[section]["unreviewed"] = "new value"
                with self.assertRaisesRegex(ValueError, "every key exactly once"):
                    self.prepare()
                del self.package[section]["unreviewed"]

    def test_missing_duplicate_and_overlapping_classifications_fail(self):
        original = copy.deepcopy(self.policy["package"]["scripts"])
        for values in ([], ["start", "start"], ["start", "check"], ["start", "absent"]):
            with self.subTest(values=values):
                self.policy["package"]["scripts"]["product"] = values
                with self.assertRaisesRegex(ValueError, "every key exactly once"):
                    self.prepare()
        self.policy["package"]["scripts"] = original

    def test_source_and_override_edits_require_new_review(self):
        for name in ("README.md", "distribution/product/README.md"):
            with self.subTest(name=name):
                original = self.master[name]
                self.master[name] += b"Substantive change\n"
                policy_before = copy.deepcopy(self.policy)
                with self.assertRaisesRegex(ValueError, "review is stale"):
                    self.prepare()
                self.assertEqual(self.policy, policy_before)
                self.master[name] = original

    def test_checkout_line_endings_do_not_invalidate_review(self):
        for name in self.master:
            self.master[name] = self.master[name].replace(b"\n", b"\r\n")
        self.assertEqual(self.prepare()["scripts"], {"start": "electron ."})

    def test_missing_or_extra_override_bindings_fail(self):
        original = copy.deepcopy(self.policy["overrides"])
        for bindings in ({}, {**original, "absent.md": {}}):
            with self.subTest(bindings=bindings):
                self.policy["overrides"] = bindings
                with self.assertRaisesRegex(ValueError, "exactly cover"):
                    self.prepare()

    def test_new_dependency_section_cannot_bypass_classification(self):
        self.package["optionalDependencies"] = {"unreviewed": "1"}
        with self.assertRaisesRegex(ValueError, "requires policy review"):
            self.prepare()


if __name__ == "__main__":
    unittest.main()
