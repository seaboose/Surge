const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { build } = require("./build.cjs");

test("frozen renderer build includes the served font path and its license", () => {
  const root = path.resolve(
    process.env.SURGE_UI_TEST_OUTPUT || path.join(__dirname, "../verification"),
  );
  fs.mkdirSync(root, { recursive: true });
  const work = fs.mkdtempSync(path.join(root, "renderer-build-"));
  const sourceDir = path.join(work, "frozen-source");
  const outputDir = path.join(work, "payload", "desktop", "dist");
  fs.cpSync(path.join(__dirname, "src"), sourceDir, { recursive: true });
  build(false, {
    sourceDir,
    outputDir,
    nodePaths: [path.join(__dirname, "node_modules")],
  });
  const css = fs.readFileSync(path.join(outputDir, "app.css"), "utf8");
  assert.match(css, /fonts\/Inter-Variable\.ttf/);
  assert.deepEqual(
    fs.readFileSync(path.join(outputDir, "fonts/Inter-Variable.ttf")),
    fs.readFileSync(path.join(sourceDir, "fonts/Inter-Variable.ttf")),
  );
  assert.deepEqual(
    fs.readFileSync(path.join(outputDir, "fonts/Inter-OFL.txt")),
    fs.readFileSync(path.join(sourceDir, "fonts/Inter-OFL.txt")),
  );
  for (const name of ["app.js", "app.css", "index.html", "style.css"])
    assert.ok(fs.statSync(path.join(outputDir, name)).size > 0, name);
  assert.equal(fs.existsSync(path.join(outputDir, "app.js.map")), false);
});
