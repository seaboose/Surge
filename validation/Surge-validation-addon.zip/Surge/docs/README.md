# Documentation

- [Five-minute demo](standalone-demo.md): record, inspect, and export a report.
- [Code guide](code-map.md): follow a recording through the implementation.
- [Development](development.md): setup, tests, and source layout.
- [Software and validation separation](distribution.md): file placement, feature workflow, and matching exports.
- [Architecture](architecture.md): process boundaries and evidence flow.
- [Landing and preferences](landing-design.md): entry points, saved work and display settings.
- [Validation](validation.md): verified results and remaining limits.
- [Release checklist](release-checklist.md): repeatable steps for future updates.

For details: [gameplay workflow](survive-workflow.md),
[report editor](survive-investigations.md), [study protocol](survive-study.md),
[packaging](runtime-release-scope.md), and [security](../SECURITY.md).

Other files in this directory document test procedures and acceptance criteria
used by the development scripts. They are not additional product features.
