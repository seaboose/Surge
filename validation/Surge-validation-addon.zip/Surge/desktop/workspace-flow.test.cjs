// Real workspace journey. Only native file pickers are supplied by the driver;
// capture, analysis, navigation, saving and export use the application's controls.
const { _electron: electron } = require("playwright");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { revealExport } = require("./test-export-menu.cjs");
const outputRoot = path.resolve(
  process.env.SURGE_UI_TEST_OUTPUT || path.join(__dirname, "../verification"),
);
fs.mkdirSync(outputRoot, { recursive: true });
const out = fs.mkdtempSync(path.join(outputRoot, "workspace-flow-"));
const profile = path.join(out, "profile");
const executable = process.env.SURGE_TEST_EXECUTABLE
  ? path.resolve(process.env.SURGE_TEST_EXECUTABLE)
  : null;
const entry = path.join(out, "entry.cjs");
fs.writeFileSync(
  entry,
  `const {app}=require('electron');app.setPath('userData',${JSON.stringify(profile)});require(${JSON.stringify(path.join(__dirname, "main.cjs"))});`,
);
const fixturePath = path.resolve(
  __dirname,
  "../demos/native/changed-code.case.json",
);
const fixture = JSON.parse(fs.readFileSync(fixturePath, "utf8"));
let app, page;
const checks = [],
  errors = [],
  measurements = [];
const button = (name, scope = page) =>
  scope.getByRole("button", { name, exact: true });
const ready = () =>
  page.waitForFunction(
    () => document.querySelector(".app")?.dataset.working === "false",
  );
const read = (method, args = {}) =>
  page.evaluate(
    async ({ method, args }) => {
      const reply = await window.surge.request(method, args);
      if (!reply.ok) throw Error(reply.error);
      return reply.value;
    },
    { method, args },
  );
async function click(name, scope = page) {
  await button(name, scope).click();
  await ready();
}
async function check(name, action) {
  await action();
  checks.push(name);
  console.log("PASS", name);
}
async function view(name) {
  await click(
    name,
    page.getByRole("navigation", { name: "Investigation views", exact: true }),
  );
}
async function size(width, height) {
  await app.evaluate(
    ({ BrowserWindow }, dimensions) =>
      BrowserWindow.getAllWindows()[0].setContentSize(...dimensions),
    [width, height],
  );
  await page.waitForFunction(
    (dimensions) =>
      innerWidth === dimensions[0] && innerHeight === dimensions[1],
    [width, height],
  );
}
async function audit(name) {
  await page.evaluate(() => document.fonts.ready);
  const measure = await page.evaluate(() => ({
    width: innerWidth,
    height: innerHeight,
    overflow: document.documentElement.scrollWidth > innerWidth + 2,
    clippedButtons: [...document.querySelectorAll("button")]
      .filter(
        (element) =>
          element.checkVisibility() &&
          element.scrollWidth > element.clientWidth + 3,
      )
      .map((element) => element.textContent.trim()),
  }));
  measurements.push({ name, ...measure });
  assert.equal(measure.overflow, false, `${name}: page horizontal overflow`);
  assert.deepEqual(
    measure.clippedButtons,
    [],
    `${name}: clipped button labels`,
  );
  await page.screenshot({ path: path.join(out, name + ".png") });
}
async function picker(file) {
  await app.evaluate(({ dialog }, file) => {
    dialog.showOpenDialog = async () => ({
      canceled: false,
      filePaths: [file],
    });
  }, file);
}
async function waitRows(count) {
  await page.waitForFunction(
    (count) =>
      document.querySelectorAll(
        '#workspace-results table[aria-label="Results"] tbody tr',
      ).length === count,
    count,
  );
}
async function library() {
  await click("Tools", page.locator(".instrument-header"));
  await click(
    "Case library",
    page.getByRole("navigation", { name: "Views", exact: true }),
  );
  const dialog = page.getByRole("dialog", {
    name: "Case library",
    exact: true,
  });
  await dialog.waitFor();
  return dialog;
}
(async () => {
  const env = {
    ...process.env,
    SURGE_PRESENTATION: '{"point":{"x":-540,"y":936},"hidden":true}',
  };
  delete env.ELECTRON_RUN_AS_NODE;
  app = await electron.launch({
    executablePath: executable || require("electron"),
    args: executable ? [`--user-data-dir=${profile}`] : [entry],
    cwd: executable ? path.dirname(executable) : __dirname,
    chromiumSandbox: true,
    env,
  });
  page = await app.firstWindow();
  page.setDefaultTimeout(15000);
  page.on("pageerror", (error) => errors.push(error.message));
  await button("Open evidence").waitFor();
  const identity = await app.evaluate(({ app, BrowserWindow }) => ({
    packaged: app.isPackaged,
    executable: process.execPath,
    profile: app.getPath("userData"),
    hidden: !BrowserWindow.getAllWindows()[0].isVisible(),
    preferences:
      BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences(),
  }));
  assert.equal(identity.packaged, !!executable);
  assert.equal(
    path.resolve(identity.profile).toLowerCase(),
    profile.toLowerCase(),
  );
  assert.equal(identity.hidden, true);
  assert.equal(identity.preferences.sandbox, true);
  assert.equal(identity.preferences.contextIsolation, true);
  assert.equal(identity.preferences.nodeIntegration, false);
  if (executable)
    assert.equal(
      path.resolve(identity.executable).toLowerCase(),
      executable.toLowerCase(),
    );
  await size(1920, 1080);

  await check(
    "capture exposes real controls and keeps its snapshot fixed",
    async () => {
      await click("Start capture");
      await click("Owned process");
      const capture = page.getByRole("region", {
        name: "Capture controls",
        exact: true,
      });
      await capture.waitFor();
      await capture.getByText("About this source", { exact: true }).waitFor();
      assert.equal(
        await capture
          .getByText("About this demo and its results", { exact: true })
          .count(),
        0,
      );
      await click("Start collection", capture);
      await page.waitForFunction(async () => {
        const reply = await window.surge.request("native_status", {});
        if (!reply.ok) throw Error(reply.error);
        if (reply.value.capture?.state === "failed")
          throw Error(reply.value.capture.error);
        return reply.value.capture?.samples >= 2;
      });
      await page.waitForFunction(
        () =>
          ![...document.querySelectorAll("button")].find(
            (button) => button.textContent === "Inspect snapshot",
          )?.disabled,
      );
      await audit("capture-1920x1080");
      await click("Inspect snapshot", capture);
      await page.getByRole("table", { name: "Results", exact: true }).waitFor();
      const snapshot = await read("state");
      assert.ok(snapshot.summary.total >= 4);
      assert.equal(snapshot.inspected_capture.capture_state, "running");
      await page.waitForFunction(async (sequence) => {
        const reply = await window.surge.request("native_status", {});
        return reply.ok && reply.value.capture.final_sequence > sequence;
      }, snapshot.inspected_capture.final_sequence);
      assert.equal(
        (await read("state")).current.sha256,
        snapshot.current.sha256,
      );
      await capture.getByText(/Newer samples available/).waitFor();
      await click("Stop collection", capture);
      const stopped = await read("native_status"),
        final = await read("state");
      assert.equal(stopped.capture.state, "stopped");
      assert.equal(final.inspected_capture.capture_state, "stopped");
      assert.equal(
        final.inspected_capture.final_sequence,
        stopped.capture.final_sequence,
      );
      assert.ok(final.summary.total >= snapshot.summary.total);
      await capture
        .getByText("Final snapshot open.", { exact: true })
        .waitFor();
    },
  );

  await check(
    "portable case opens with honest native range evidence",
    async () => {
      await picker(fixturePath);
      await click("Open case file", await library());
      await page.getByRole("table", { name: "Results", exact: true }).waitFor();
      const state = await read("state");
      assert.equal(state.current.sha256, fixture.payload.current.sha256);
      assert.equal(state.summary.total, 4);
      assert.equal(state.summary.Review, 1);
      assert.equal(state.summary.Unknown, 0);
      await page.getByLabel("Findings only", { exact: true }).uncheck();
      await waitRows(4);
      await button("Inspect record 3").click();
      const evidence = page.getByRole("region", {
        name: "Record evidence",
        exact: true,
      });
      await evidence
        .getByRole("heading", { name: "Code changed", exact: true })
        .waitFor();
      assert.equal(await evidence.locator("mark").first().innerText(), "8a");
      await click("Close inspector");
      assert.equal(await evidence.isVisible(), false);
      assert.equal(
        await button("Inspect record 3").evaluate(
          (element) => element === document.activeElement,
        ),
        true,
      );
      await button("Inspect record 3").click();
      await evidence.getByText("Source values", { exact: true }).click();
      await evidence.getByText("observed_hex", { exact: true }).waitFor();
      assert.match(await evidence.innerText(), /8ac183f03583c011c3/);
      await evidence.getByText("Source values", { exact: true }).click();
      assert.equal(await button("Close inspector").isVisible(), true);
      await evidence.evaluate((element) => (element.scrollTop = 0));
      await audit("investigation-1920x1080");
    },
  );

  await check(
    "search, priority filters and exported alerts agree",
    async () => {
      const search = page.getByLabel("Search records", { exact: true });
      await search.fill("LabCodeSecondary");
      await waitRows(2);
      assert.deepEqual(
        await page
          .locator(".results-table tbody tr")
          .evaluateAll((rows) => rows.map((row) => row.dataset.row)),
        ["2", "4"],
      );
      await search.fill("");
      await waitRows(4);
      await page.getByLabel("Findings only", { exact: true }).check();
      await waitRows(1);
      await page
        .getByLabel("Priority", { exact: true })
        .selectOption("Critical");
      await waitRows(0);
      await button("Show all observations").click();
      await waitRows(4);
      await page.getByLabel("Priority", { exact: true }).selectOption("Error");
      await waitRows(1);
      const destination = path.join(out, "error-alerts.jsonl");
      await app.evaluate(({ dialog }, file) => {
        dialog.showSaveDialog = async () => ({
          canceled: false,
          filePath: file,
        });
      }, destination);
      await revealExport(page, "Export alerts");
      await click("Export alerts");
      const exported = fs
        .readFileSync(destination, "utf8")
        .trim()
        .split("\n")
        .map(JSON.parse);
      assert.equal(exported[0].minimum_priority, "Error");
      assert.equal(exported[0].alerts, 1);
      assert.equal(exported.length, 2);
      assert.equal(exported[1].row, 3);
      assert.equal(exported[1].source_record.memory_matches, false);
      await page.getByLabel("Priority", { exact: true }).selectOption("All");
      await waitRows(4);
    },
  );

  await check(
    "case saving and all investigation views remain reachable",
    async () => {
      await page
        .getByRole("button", {
          name: /^(Save case|Save a copy|Save as new case)$/,
        })
        .click();
      await page
        .getByLabel("Case name", { exact: true })
        .fill("Changed range review");
      await click("Save to library");
      assert.equal((await read("library_list")).entries.length, 1);
      const dialog = await library();
      await dialog.getByText("Changed range review", { exact: true }).waitFor();
      await audit("library-1920x1080");
      await click("Close", dialog);
      await view("Data");
      await page.getByRole("table", { name: "Preview", exact: true }).waitFor();
      await audit("data-1920x1080");
      await view("Compare");
      await button("Choose case").waitFor();
      await audit("compare-1920x1080");
      await view("Evaluate");
      await button("Import labels").waitFor();
      await audit("evaluate-1920x1080");
      await view("Case details");
      await page
        .locator("#workspace-details")
        .getByText("Analysis settings", { exact: true })
        .waitFor();
      await audit("case-details-1920x1080");
      assert.equal(
        (await read("state")).current.sha256,
        fixture.payload.current.sha256,
      );
      await view("Results");
      await button("Inspect record 3").click();
    },
  );

  await check(
    "compact and portrait layouts retain the workspace and dialogs",
    async () => {
      for (const [width, height] of [
        [1080, 1872],
        [760, 880],
        [390, 844],
      ]) {
        await size(width, height);
        await audit(`investigation-${width}x${height}`);
        await click("Settings", page.locator(".instrument-header"));
        await page
          .getByRole("dialog", { name: "Settings", exact: true })
          .waitFor();
        await audit(`settings-${width}x${height}`);
        await page.keyboard.press("Escape");
        for (const name of ["Data", "Compare", "Evaluate", "Case details"]) {
          await view(name);
          await audit(
            `${name.toLowerCase().replaceAll(" ", "-")}-${width}x${height}`,
          );
        }
        await view("Results");
      }
      await size(1920, 1080);
      await click("Settings", page.locator(".instrument-header"));
      await audit("settings-1920x1080");
      await page.keyboard.press("Escape");
      await click("Home");
      await click("Start capture");
      await click("Owned process");
      for (const [width, height] of [
        [1080, 1872],
        [760, 880],
        [390, 844],
      ]) {
        await size(width, height);
        await audit(`capture-${width}x${height}`);
      }
    },
  );
  assert.deepEqual(errors, []);
  const result = {
    passed: true,
    checks,
    identity,
    measurements,
    errors,
    evidence: out,
  };
  fs.writeFileSync(
    path.join(out, "result.json"),
    JSON.stringify(result, null, 2),
  );
  console.log(JSON.stringify(result));
})()
  .catch(async (error) => {
    console.error(error);
    process.exitCode = 1;
    fs.writeFileSync(
      path.join(out, "failure.json"),
      JSON.stringify(
        { message: error.message, checks, errors, measurements },
        null,
        2,
      ),
    );
    if (page)
      await page
        .screenshot({ path: path.join(out, "failure.png") })
        .catch(() => {});
  })
  .finally(async () => {
    if (app) await app.close();
  });
