async function revealEvidenceDetails(page, label) {
  const region = page.getByRole("region", {
    name: "Record evidence",
    exact: true,
  });
  const summary = region.getByText(label, { exact: true });
  await summary.waitFor();
  if (!(await summary.evaluate((element) => element.parentElement.open)))
    await summary.click();
}

module.exports = { revealEvidenceDetails };
